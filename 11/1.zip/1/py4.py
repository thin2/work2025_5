from lab11 import *
print(line(5, '*'))

print(mixedLine(5, '*', 10, '!'))

print(rectangle(3, 5, '!'))

print(rectangle(3, 5))

print(triangle(5, '#'))

print(triangle(8))
